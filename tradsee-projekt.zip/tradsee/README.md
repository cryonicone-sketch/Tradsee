# Tradsee

Unabhängige Chart-App für Android mit eigener Chart-Engine (Canvas, keine Fremdbibliotheken).
Kurse: öffentliche Binance-Daten (Krypto), ohne API-Key.

## Funktionen

- Chart-Typen: Kerzen, Balken, Linie, Fläche, Heikin Ashi
- Zeitrahmen: 1m, 5m, 15m, 1h, 4h, 1T, 1W, Live-Kurse per WebSocket, älteres Laden beim Zurückscrollen
- Indikatoren: SMA, EMA, Bollinger-Bänder, Volumen, RSI, MACD (Perioden einstellbar)
- Zeichenwerkzeuge: Trendlinie, waagerechte Linie, Fibonacci-Retracement, Zone (Rechteck), mit Magnet-Modus, Verschieben der Endpunkte und Löschen
- Watchlist mit Live-Preisen und 24h-Änderung, Suche, eigene Symbole (z. B. `PEPEUSDT`)
- Wischen = verschieben, zwei Finger = zoomen, langes Drücken = Fadenkreuz, Doppeltippen = Ansicht zurücksetzen
- Alles (Zeichnungen, Favoriten, Einstellungen) bleibt lokal auf dem Gerät

## APK bauen

Eine fertige APK liegt nicht bei, weil dafür das Android SDK nötig ist. Drei Wege:

**A) Android Studio** (am einfachsten)
1. Android Studio installieren, diesen Ordner mit *Open* öffnen und den Gradle-Sync abwarten.
2. Menü *Build → Build Bundle(s) / APK(s) → Build APK(s)*.
3. Die Datei liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

**B) GitHub (ohne Installation am PC)**
1. Ein (privates) Repository anlegen und den kompletten Ordnerinhalt hochladen.
2. Reiter *Actions → Tradsee APK bauen → Run workflow*.
3. Nach ein paar Minuten das Artefakt `tradsee-apk` herunterladen und entpacken.

**C) Kommandozeile** (JDK 17 und Android SDK vorhanden)
```
./gradlew assembleDebug
```

## Installieren

APK aufs Handy kopieren, öffnen und das Installieren aus dieser Quelle erlauben ("Unbekannte Apps installieren").
Die Debug-APK ist mit dem Debug-Schlüssel signiert und für den privaten Gebrauch gedacht.

## Schnelltest ohne APK

Die gesamte App liegt in `app/src/main/assets/`. Im Ordner einen lokalen Server starten und im Browser öffnen
(am besten in der mobilen Ansicht der Entwicklertools):

```
cd app/src/main/assets
python3 -m http.server 8080
```

Ohne Internetverbindung zeigt Tradsee deutlich gekennzeichnete Demo-Daten.

## Andere Märkte (Aktien, Forex) ergänzen

Die Datenquelle ist das Objekt `Provider` in `app/src/main/assets/app.js` mit den Methoden `klines()`,
`tickers()` und `stream()`. Für Aktien oder Forex dort eine Quelle mit eigenem API-Key einbauen
(zum Beispiel Twelve Data oder Alpha Vantage) und die Antworten in dasselbe Format bringen:
`{ t: Sekunden, o, h, l, c, v }`.

## Hinweise

- Tradsee steht in keiner Verbindung zu TradingView; Name, Gestaltung und Code sind eigenständig.
- Keine Anlageberatung. Kurse können verzögert oder fehlerhaft sein.
- Die Chart-Logik wurde mit Testläufen geprüft. Das Android-Projekt selbst konnte in der Entwicklungsumgebung
  nicht gebaut werden (kein Android SDK, kein Zugriff auf Google/Maven). Falls der erste Build eine Fehlermeldung
  zeigt, schick sie einfach her.
