/* Tradsee – eigene Canvas-Chart-Engine (keine Fremdbibliotheken) */
(function (root) {
  'use strict';

  const THEME = {
    bg: '#0b0f17', grid: 'rgba(148,163,184,0.09)', axis: '#7b8598', text: '#c5cddb',
    up: '#2ee6a6', down: '#ff5d73', line: '#e8eefb', accent: '#8b7cff', amber: '#ffb547',
    cyan: '#4cc9f0', pink: '#f472b6', cross: 'rgba(200,210,230,0.55)', tag: '#1c2438'
  };
  const FONT = '11px -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  const FIB = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
  const FIB_COL = ['#7b8598', '#ff5d73', '#ffb547', '#2ee6a6', '#4cc9f0', '#8b7cff', '#7b8598'];

  /* ---------- Indikator-Berechnung ---------- */
  const calc = {
    sma(v, n) {
      const out = new Array(v.length).fill(NaN);
      let s = 0;
      for (let i = 0; i < v.length; i++) {
        s += v[i];
        if (i >= n) s -= v[i - n];
        if (i >= n - 1) out[i] = s / n;
      }
      return out;
    },
    ema(v, n) {
      const out = new Array(v.length).fill(NaN);
      let start = 0;
      while (start < v.length && isNaN(v[start])) start++;
      if (v.length - start < n) return out;
      const k = 2 / (n + 1);
      let sum = 0;
      for (let i = start; i < start + n; i++) sum += v[i];
      let e = sum / n;
      out[start + n - 1] = e;
      for (let i = start + n; i < v.length; i++) {
        e = v[i] * k + e * (1 - k);
        out[i] = e;
      }
      return out;
    },
    boll(v, n, m) {
      const mid = this.sma(v, n);
      const up = new Array(v.length).fill(NaN);
      const lo = new Array(v.length).fill(NaN);
      for (let i = n - 1; i < v.length; i++) {
        let s = 0;
        for (let j = i - n + 1; j <= i; j++) { const d = v[j] - mid[i]; s += d * d; }
        const sd = Math.sqrt(s / n);
        up[i] = mid[i] + m * sd;
        lo[i] = mid[i] - m * sd;
      }
      return { mid, up, lo };
    },
    rsi(v, n) {
      const out = new Array(v.length).fill(NaN);
      if (v.length <= n) return out;
      let g = 0, l = 0;
      for (let i = 1; i <= n; i++) {
        const d = v[i] - v[i - 1];
        if (d >= 0) g += d; else l -= d;
      }
      g /= n; l /= n;
      out[n] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
      for (let i = n + 1; i < v.length; i++) {
        const d = v[i] - v[i - 1];
        g = (g * (n - 1) + Math.max(d, 0)) / n;
        l = (l * (n - 1) + Math.max(-d, 0)) / n;
        out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
      }
      return out;
    },
    macd(v, f, s, sig) {
      const ef = this.ema(v, f), es = this.ema(v, s);
      const m = v.map((_, i) => (isNaN(ef[i]) || isNaN(es[i])) ? NaN : ef[i] - es[i]);
      const sg = this.ema(m, sig);
      const hist = m.map((x, i) => (isNaN(x) || isNaN(sg[i])) ? NaN : x - sg[i]);
      return { macd: m, signal: sg, hist };
    }
  };

  /* ---------- Hilfsfunktionen ---------- */
  const MON = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
  const DOW = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const p2 = n => String(n).padStart(2, '0');
  const nfCache = {};
  function fmt(p, d) {
    if (!nfCache[d]) nfCache[d] = new Intl.NumberFormat('de-DE', { minimumFractionDigits: d, maximumFractionDigits: d });
    return nfCache[d].format(p);
  }
  function autoDec(p) {
    const a = Math.abs(p);
    return a >= 100 ? 2 : a >= 10 ? 3 : a >= 1 ? 4 : a >= 0.1 ? 5 : a >= 0.01 ? 6 : 8;
  }
  function fmtTime(t, tfSec) {
    const d = new Date(t * 1000);
    const date = `${DOW[d.getDay()]} ${p2(d.getDate())}. ${MON[d.getMonth()]} '${String(d.getFullYear()).slice(2)}`;
    return tfSec >= 86400 ? date : `${date}  ${p2(d.getHours())}:${p2(d.getMinutes())}`;
  }
  function niceStep(range, target) {
    const raw = range / target;
    const p = Math.pow(10, Math.floor(Math.log10(raw)));
    const f = raw / p;
    return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
  }
  function distSeg(p, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const l2 = dx * dx + dy * dy;
    let t = l2 ? ((p.x - x1) * dx + (p.y - y1) * dy) / l2 : 0;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(p.x - (x1 + t * dx), p.y - (y1 + t * dy));
  }
  const uid = () => 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  const TICKS = [60, 300, 900, 1800, 3600, 7200, 14400, 21600, 43200, 86400, 172800, 604800];

  /* ---------- Chart ---------- */
  class TradseeChart {
    constructor(cv, cb) {
      this.cv = cv;
      this.ctx = cv.getContext('2d');
      this.cb = cb || {};
      this.data = []; this.ha = [];
      this.tfSec = 3600; this.type = 'candles';
      this.bw = 8; this.rightOff = 6;
      this.drawings = []; this.selId = null;
      this.tool = null; this.pending = null; this.magnet = true;
      this.cross = null; this.dirty = true; this.indDirty = true;
      this.dpr = 1; this.W = 300; this.H = 300; this.axisW = 56; this.timeH = 24;
      this.panes = []; this.plotW = 244; this.I = {};
      this.ind = {
        sma: { on: true, n: 20 }, ema: { on: false, n: 50 }, bb: { on: false, n: 20, k: 2 },
        vol: { on: true }, rsi: { on: false, n: 14 }, macd: { on: false }
      };
      this.ptrs = new Map(); this.mode = null;
      this._bind();
      this.resize();
      const loop = () => { if (this.dirty) { this.dirty = false; this.draw(); } requestAnimationFrame(loop); };
      loop();
      setInterval(() => { this.dirty = true; }, 1000);
    }

    /* --- Daten --- */
    setData(data, tfSec, reset) {
      this.data = data; this.tfSec = tfSec;
      if (reset) { this.rightOff = 6; this.bw = this.bw || 8; this.cross = null; this.pending = null; }
      this._buildHA(); this.indDirty = true; this.dirty = true;
      this._viewChanged();
    }
    prepend(older) {
      if (!older.length) return;
      const first = this.data[0] ? this.data[0].t : Infinity;
      older = older.filter(b => b.t < first);
      if (!older.length) return;
      this.data = older.concat(this.data);
      this._buildHA(); this.indDirty = true; this.dirty = true;
    }
    updateBar(bar) {
      const n = this.data.length;
      const last = this.data[n - 1];
      if (!last || bar.t > last.t) {
        this.data.push(bar);
        if (this.rightOff < 0) this.rightOff -= 1;
      } else if (bar.t === last.t) {
        this.data[n - 1] = bar;
      } else return;
      if (this.type === 'ha') this._buildHA();
      this.indDirty = true; this.dirty = true;
    }
    _buildHA() {
      const d = this.data, ha = [];
      for (let i = 0; i < d.length; i++) {
        const c = (d[i].o + d[i].h + d[i].l + d[i].c) / 4;
        const o = i ? (ha[i - 1].o + ha[i - 1].c) / 2 : (d[i].o + d[i].c) / 2;
        ha.push({ t: d[i].t, o, c, h: Math.max(d[i].h, o, c), l: Math.min(d[i].l, o, c), v: d[i].v });
      }
      this.ha = ha;
    }
    setType(t) { this.type = t; if (t === 'ha') this._buildHA(); this.dirty = true; }
    setIndicators(ind) { this.ind = ind; this.indDirty = true; this.dirty = true; }
    get src() { return this.type === 'ha' ? this.ha : this.data; }

    _ensureInd() {
      if (!this.indDirty) return;
      this.indDirty = false;
      const c = this.data.map(b => b.c), I = {}, g = this.ind;
      if (g.sma.on) I.sma = calc.sma(c, g.sma.n);
      if (g.ema.on) I.ema = calc.ema(c, g.ema.n);
      if (g.bb.on) I.bb = calc.boll(c, g.bb.n, g.bb.k);
      if (g.rsi.on) I.rsi = calc.rsi(c, g.rsi.n);
      if (g.macd.on) I.macd = calc.macd(c, 12, 26, 9);
      this.I = I;
    }

    /* --- Koordinaten --- */
    resize() {
      const r = this.cv.getBoundingClientRect();
      this.dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
      this.W = Math.max(50, Math.floor(r.width));
      this.H = Math.max(50, Math.floor(r.height));
      this.cv.width = Math.round(this.W * this.dpr);
      this.cv.height = Math.round(this.H * this.dpr);
      this.dirty = true;
    }
    iRight() { return this.data.length - 1 + this.rightOff; }
    iLeft() { return this.iRight() - this.plotW / this.bw; }
    x(i) { return this.plotW - (this.iRight() - i + 0.5) * this.bw; }
    idxAt(x) { return this.iRight() + 0.5 - (this.plotW - x) / this.bw; }
    timeToIdx(t) {
      const d = this.data, n = d.length;
      if (!n) return 0;
      if (t >= d[n - 1].t) return n - 1 + (t - d[n - 1].t) / this.tfSec;
      if (t <= d[0].t) return (t - d[0].t) / this.tfSec;
      let lo = 0, hi = n - 1;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (d[m].t <= t) lo = m; else hi = m; }
      return lo + (t - d[lo].t) / (d[hi].t - d[lo].t);
    }
    idxToTime(i) {
      const d = this.data, n = d.length;
      if (!n) return 0;
      if (i >= n - 1) return d[n - 1].t + Math.round(i - (n - 1)) * this.tfSec;
      if (i <= 0) return d[0].t + Math.round(i) * this.tfSec;
      return d[Math.round(i)].t;
    }
    timeToX(t) { return this.x(this.timeToIdx(t)); }
    priceToY(v, pane) { pane = pane || this.panes[0]; return pane.top + (pane.hi - v) / (pane.hi - pane.lo) * pane.h; }
    yToPrice(y, pane) { pane = pane || this.panes[0]; return pane.hi - (y - pane.top) / pane.h * (pane.hi - pane.lo); }
    paneAt(y) { for (const p of this.panes) if (y >= p.top && y < p.top + p.h) return p; return null; }

    _clampView() {
      const n = this.data.length;
      const maxOff = this.plotW / this.bw - 5;
      const minOff = 5 - (n - 1);
      this.rightOff = Math.max(minOff, Math.min(maxOff, this.rightOff));
      this.bw = Math.max(1.5, Math.min(60, this.bw));
    }
    _viewChanged() {
      this._clampView();
      if (this.cb.onView) this.cb.onView(this.rightOff);
      if (this.iLeft() < 30 && this.cb.onNeedMore) this.cb.onNeedMore();
    }
    zoomTo(bw, ax) {
      const iA = this.idxAt(ax);
      this.bw = Math.max(1.5, Math.min(60, bw));
      const iR = iA - 0.5 + (this.plotW - ax) / this.bw;
      this.rightOff = iR - (this.data.length - 1);
      this._viewChanged(); this.dirty = true;
    }
    resetView() { this.bw = 8; this.rightOff = 6; this._viewChanged(); this.dirty = true; }

    /* --- Layout & Skalen --- */
    _layout() {
      const c = this.ctx;
      c.font = FONT;
      const last = this.data.length ? this.data[this.data.length - 1].c : 1;
      this.dec = autoDec(last);
      this.axisW = Math.max(52, Math.ceil(c.measureText(fmt(last * 1.001, this.dec)).width) + 16);
      this.plotW = this.W - this.axisW;
      const subs = [];
      if (this.ind.rsi.on) subs.push('rsi');
      if (this.ind.macd.on) subs.push('macd');
      const avail = this.H - this.timeH;
      const subH = subs.length ? Math.max(56, Math.min(120, Math.floor(avail * 0.2))) : 0;
      const mainH = avail - subH * subs.length;
      this.panes = [{ id: 'main', top: 0, h: mainH, lo: 0, hi: 1 }];
      subs.forEach((id, k) => this.panes.push({ id, top: mainH + k * subH, h: subH, lo: 0, hi: 1 }));
      this.timeTop = avail;
    }
    _scales() {
      const n = this.data.length;
      const iL = Math.max(0, Math.floor(this.iLeft())), iR = Math.min(n - 1, Math.ceil(this.iRight()));
      this.vis = [iL, iR];
      const s = this.src, line = this.type === 'line' || this.type === 'area';
      let lo = Infinity, hi = -Infinity;
      for (let i = iL; i <= iR; i++) {
        const b = s[i];
        if (line) { if (b.c < lo) lo = b.c; if (b.c > hi) hi = b.c; }
        else { if (b.l < lo) lo = b.l; if (b.h > hi) hi = b.h; }
        if (this.I.bb) {
          const u = this.I.bb.up[i], l = this.I.bb.lo[i];
          if (!isNaN(u) && u > hi) hi = u;
          if (!isNaN(l) && l < lo) lo = l;
        }
      }
      if (!isFinite(lo)) { lo = 0; hi = 1; }
      if (hi === lo) { hi += 1; lo -= 1; }
      const r = hi - lo;
      const m = this.panes[0];
      m.lo = lo - r * (this.ind.vol.on ? 0.2 : 0.08);
      m.hi = hi + r * 0.08;
      for (const p of this.panes) {
        if (p.id === 'rsi') { p.lo = -4; p.hi = 104; }
        if (p.id === 'macd') {
          let mx = 1e-12;
          const M = this.I.macd;
          if (M) for (let i = iL; i <= iR; i++) {
            for (const a of [M.macd[i], M.signal[i], M.hist[i]]) if (!isNaN(a) && Math.abs(a) > mx) mx = Math.abs(a);
          }
          p.lo = -mx * 1.2; p.hi = mx * 1.2;
        }
      }
    }

    /* --- Zeichnen --- */
    draw() {
      const c = this.ctx;
      c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      c.fillStyle = THEME.bg;
      c.fillRect(0, 0, this.W, this.H);
      if (!this.data.length) { this._legend(-1); return; }
      this._layout();
      this._ensureInd();
      this._scales();
      c.font = FONT;
      this._grid();
      this._mainPane();
      for (const p of this.panes.slice(1)) this._subPane(p);
      this._drawings();
      this._axes();
      this._crosshair();
      this._legend(this.cross ? this._crossIdx() : this.data.length - 1);
    }

    _grid() {
      const c = this.ctx;
      c.strokeStyle = THEME.grid; c.lineWidth = 1;
      c.beginPath();
      const m = this.panes[0];
      const step = niceStep(m.hi - m.lo, Math.max(3, m.h / 60));
      for (let v = Math.ceil(m.lo / step) * step; v < m.hi; v += step) {
        const y = Math.round(this.priceToY(v, m)) + 0.5;
        c.moveTo(0, y); c.lineTo(this.plotW, y);
      }
      for (const t of this._timeTicks()) {
        const x = Math.round(t.x) + 0.5;
        c.moveTo(x, 0); c.lineTo(x, this.timeTop);
      }
      for (let k = 1; k < this.panes.length; k++) {
        const y = Math.round(this.panes[k].top) + 0.5;
        c.moveTo(0, y); c.lineTo(this.W, y);
      }
      c.stroke();
      c.strokeStyle = 'rgba(148,163,184,0.16)';
      c.beginPath();
      c.moveTo(this.plotW + 0.5, 0); c.lineTo(this.plotW + 0.5, this.H);
      c.moveTo(0, this.timeTop + 0.5); c.lineTo(this.W, this.timeTop + 0.5);
      c.stroke();
    }

    _timeTicks() {
      const out = [];
      if (!this.data.length) return out;
      const tL = this.idxToTime(this.iLeft()), tR = this.idxToTime(this.iRight());
      const minPx = 78;
      const secPerPx = this.tfSec / this.bw;
      const needSec = minPx * secPerPx;
      if (needSec > 86400 * 40) {
        const months = needSec > 86400 * 200 ? 12 : needSec > 86400 * 100 ? 6 : needSec > 86400 * 60 ? 3 : 1;
        const d = new Date(tL * 1000);
        d.setDate(1); d.setHours(0, 0, 0, 0);
        d.setMonth(d.getMonth() - (d.getMonth() % months));
        for (let k = 0; k < 400 && d.getTime() / 1000 <= tR; k++) {
          const t = d.getTime() / 1000;
          const lbl = months === 12 ? String(d.getFullYear()) : `${MON[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
          if (t >= tL) out.push({ x: this.timeToX(t), label: lbl });
          d.setMonth(d.getMonth() + months);
        }
        return out;
      }
      let cand = TICKS[TICKS.length - 1];
      for (const t of TICKS) if (t >= needSec) { cand = t; break; }
      const off = -new Date(((tL + tR) / 2) * 1000).getTimezoneOffset() * 60;
      for (let t = Math.ceil((tL + off) / cand) * cand - off, k = 0; t <= tR && k < 200; t += cand, k++) {
        const d = new Date(t * 1000);
        let label;
        if (cand < 86400) label = (d.getHours() === 0 && d.getMinutes() === 0) ? `${d.getDate()}. ${MON[d.getMonth()]}` : `${p2(d.getHours())}:${p2(d.getMinutes())}`;
        else label = `${d.getDate()}. ${MON[d.getMonth()]}`;
        out.push({ x: this.timeToX(t), label });
      }
      return out;
    }

    _clip(pane) {
      const c = this.ctx;
      c.save(); c.beginPath(); c.rect(0, pane.top, this.plotW, pane.h); c.clip();
    }

    _poly(arr, pane, color, w) {
      const c = this.ctx, [iL, iR] = this.vis;
      c.strokeStyle = color; c.lineWidth = w; c.lineJoin = 'round';
      c.beginPath();
      let pen = false;
      for (let i = Math.max(0, iL - 1); i <= Math.min(arr.length - 1, iR + 1); i++) {
        if (isNaN(arr[i])) { pen = false; continue; }
        const x = this.x(i), y = this.priceToY(arr[i], pane);
        if (pen) c.lineTo(x, y); else { c.moveTo(x, y); pen = true; }
      }
      c.stroke();
    }

    _mainPane() {
      const c = this.ctx, m = this.panes[0], s = this.src, [iL, iR] = this.vis;
      const bw = this.bw;
      this._clip(m);
      // Volumen
      if (this.ind.vol.on) {
        let mv = 0;
        for (let i = iL; i <= iR; i++) if (this.data[i].v > mv) mv = this.data[i].v;
        const vh = m.h * 0.16;
        const w = Math.max(1, bw * 0.7);
        for (let i = iL; i <= iR; i++) {
          const b = this.data[i], h = mv ? b.v / mv * vh : 0;
          c.fillStyle = b.c >= b.o ? 'rgba(46,230,166,0.22)' : 'rgba(255,93,115,0.22)';
          c.fillRect(Math.round(this.x(i) - w / 2), m.top + m.h - h, Math.max(1, Math.round(w)), h);
        }
      }
      // Bollinger-Fläche
      if (this.I.bb) {
        const B = this.I.bb;
        c.fillStyle = 'rgba(139,124,255,0.08)';
        c.beginPath();
        let started = false;
        for (let i = iL; i <= iR; i++) if (!isNaN(B.up[i])) { const x = this.x(i), y = this.priceToY(B.up[i], m); if (started) c.lineTo(x, y); else { c.moveTo(x, y); started = true; } }
        for (let i = iR; i >= iL; i--) if (!isNaN(B.lo[i])) c.lineTo(this.x(i), this.priceToY(B.lo[i], m));
        c.closePath(); c.fill();
        this._poly(B.up, m, 'rgba(139,124,255,0.7)', 1);
        this._poly(B.lo, m, 'rgba(139,124,255,0.7)', 1);
        this._poly(B.mid, m, 'rgba(139,124,255,0.45)', 1);
      }
      // Kurs
      const t = this.type;
      if (t === 'line' || t === 'area') {
        const closes = s.map(b => b.c);
        if (t === 'area') {
          const g = c.createLinearGradient(0, m.top, 0, m.top + m.h);
          g.addColorStop(0, 'rgba(139,124,255,0.35)'); g.addColorStop(1, 'rgba(139,124,255,0)');
          c.fillStyle = g;
          c.beginPath();
          c.moveTo(this.x(iL), m.top + m.h);
          for (let i = iL; i <= iR; i++) c.lineTo(this.x(i), this.priceToY(closes[i], m));
          c.lineTo(this.x(iR), m.top + m.h);
          c.closePath(); c.fill();
        }
        this._poly(closes, m, THEME.accent, 2);
      } else {
        const w = Math.max(1, Math.round(bw * 0.72));
        for (let i = iL; i <= iR; i++) {
          const b = s[i], up = b.c >= b.o;
          const col = up ? THEME.up : THEME.down;
          const x = Math.round(this.x(i)), yo = this.priceToY(b.o, m), yc = this.priceToY(b.c, m);
          const yh = this.priceToY(b.h, m), yl = this.priceToY(b.l, m);
          c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 1;
          if (t === 'bars') {
            const tick = Math.max(2, bw * 0.35);
            c.beginPath();
            c.moveTo(x + 0.5, yh); c.lineTo(x + 0.5, yl);
            c.moveTo(x - tick, yo); c.lineTo(x + 0.5, yo);
            c.moveTo(x + 0.5, yc); c.lineTo(x + tick, yc);
            c.stroke();
          } else {
            c.beginPath(); c.moveTo(x + 0.5, yh); c.lineTo(x + 0.5, yl); c.stroke();
            const top = Math.min(yo, yc), h = Math.max(1, Math.abs(yc - yo));
            if (bw < 3) { /* nur Docht */ }
            else if (up && t === 'candles') {
              // Steigende Kerzen: Rahmen mit dunkler Füllung (eigener Look)
              c.fillStyle = 'rgba(46,230,166,0.16)';
              c.fillRect(x - w / 2 + 0.5, top, w, h);
              c.strokeRect(x - w / 2 + 0.5, top + 0.5, w, Math.max(0, h - 1));
            } else c.fillRect(x - w / 2 + 0.5, top, w, h);
          }
        }
      }
      // Overlays
      if (this.I.sma) this._poly(this.I.sma, m, THEME.amber, 1.4);
      if (this.I.ema) this._poly(this.I.ema, m, THEME.cyan, 1.4);
      // letzter Kurs
      const lb = s[s.length - 1];
      const ly = this.priceToY(lb.c, m);
      if (ly >= m.top && ly <= m.top + m.h) {
        c.setLineDash([3, 3]);
        c.strokeStyle = lb.c >= lb.o ? THEME.up : THEME.down;
        c.globalAlpha = 0.7; c.lineWidth = 1;
        c.beginPath(); c.moveTo(0, Math.round(ly) + 0.5); c.lineTo(this.plotW, Math.round(ly) + 0.5); c.stroke();
        c.setLineDash([]); c.globalAlpha = 1;
      }
      c.restore();
    }

    _subPane(p) {
      const c = this.ctx, [iL, iR] = this.vis;
      this._clip(p);
      if (p.id === 'rsi') {
        const R = this.I.rsi;
        c.fillStyle = 'rgba(139,124,255,0.06)';
        c.fillRect(0, this.priceToY(70, p), this.plotW, this.priceToY(30, p) - this.priceToY(70, p));
        c.setLineDash([3, 4]); c.strokeStyle = 'rgba(148,163,184,0.35)'; c.lineWidth = 1;
        c.beginPath();
        for (const v of [30, 70]) { const y = Math.round(this.priceToY(v, p)) + 0.5; c.moveTo(0, y); c.lineTo(this.plotW, y); }
        c.stroke(); c.setLineDash([]);
        if (R) this._poly(R, p, THEME.pink, 1.4);
      } else if (p.id === 'macd') {
        const M = this.I.macd;
        const y0 = Math.round(this.priceToY(0, p)) + 0.5;
        c.strokeStyle = 'rgba(148,163,184,0.25)'; c.lineWidth = 1;
        c.beginPath(); c.moveTo(0, y0); c.lineTo(this.plotW, y0); c.stroke();
        if (M) {
          const w = Math.max(1, Math.round(this.bw * 0.6));
          for (let i = iL; i <= iR; i++) {
            const h = M.hist[i];
            if (isNaN(h)) continue;
            c.fillStyle = h >= 0 ? 'rgba(46,230,166,0.55)' : 'rgba(255,93,115,0.55)';
            const y = this.priceToY(h, p);
            c.fillRect(Math.round(this.x(i) - w / 2), Math.min(y, y0), w, Math.max(1, Math.abs(y - y0)));
          }
          this._poly(M.macd, p, THEME.cyan, 1.3);
          this._poly(M.signal, p, THEME.amber, 1.3);
        }
      }
      c.restore();
    }

    _tag(x, y, text, bg, fg, align) {
      const c = this.ctx;
      const w = Math.ceil(c.measureText(text).width) + 10, h = 17;
      let x0 = align === 'center' ? x - w / 2 : x;
      c.fillStyle = bg;
      c.beginPath();
      if (c.roundRect) c.roundRect(x0, y - h / 2, w, h, 4); else c.rect(x0, y - h / 2, w, h);
      c.fill();
      c.fillStyle = fg; c.textBaseline = 'middle'; c.textAlign = 'left';
      c.fillText(text, x0 + 5, y + 0.5);
      return w;
    }

    _axes() {
      const c = this.ctx, m = this.panes[0];
      c.fillStyle = THEME.bg;
      c.fillRect(this.plotW + 1, 0, this.axisW, this.H);
      c.fillRect(0, this.timeTop + 1, this.W, this.timeH);
      c.fillStyle = THEME.axis; c.textBaseline = 'middle'; c.textAlign = 'left';
      // Preis
      const step = niceStep(m.hi - m.lo, Math.max(3, m.h / 60));
      const dec = Math.max(0, Math.min(8, Math.ceil(-Math.log10(step) - 1e-9)));
      for (let v = Math.ceil(m.lo / step) * step; v < m.hi; v += step) {
        const y = this.priceToY(v, m);
        if (y < 8 || y > m.h - 6) continue;
        c.fillText(fmt(v, Math.max(dec, 0)), this.plotW + 8, y);
      }
      for (const p of this.panes.slice(1)) {
        const vals = p.id === 'rsi' ? [30, 70] : [];
        for (const v of vals) c.fillText(String(v), this.plotW + 8, this.priceToY(v, p));
      }
      // Zeit
      c.textAlign = 'center';
      for (const t of this._timeTicks()) {
        if (t.x < 14 || t.x > this.plotW - 14) continue;
        c.fillText(t.label, t.x, this.timeTop + this.timeH / 2 + 1);
      }
      // Letzter Preis
      const s = this.data, lb = s[s.length - 1];
      const ly = this.priceToY(this.src[this.src.length - 1].c, m);
      if (ly >= 10 && ly <= m.h - 10) {
        const col = lb.c >= lb.o ? THEME.up : THEME.down;
        const rem = this.tfSec - (Math.floor(Date.now() / 1000) - lb.t);
        let cd = '';
        if (rem > 0 && rem <= this.tfSec) {
          const h = Math.floor(rem / 3600), mi = Math.floor(rem % 3600 / 60), se = rem % 60;
          cd = h ? `${h}:${p2(mi)}:${p2(se)}` : `${p2(mi)}:${p2(se)}`;
        }
        c.textAlign = 'left';
        const txt = fmt(lb.c, this.dec);
        c.fillStyle = col;
        c.beginPath(); c.rect(this.plotW + 1, ly - (cd ? 15 : 9), this.axisW - 1, cd ? 30 : 18); c.fill();
        c.fillStyle = '#04120d'; c.font = 'bold 11px ' + FONT.split('px ')[1];
        c.fillText(txt, this.plotW + 6, ly - (cd ? 5 : 0));
        if (cd) { c.font = FONT; c.fillText(cd, this.plotW + 6, ly + 8); }
        c.font = FONT;
      }
      // Preis-Labels waagerechter Linien
      for (const d of this.drawings) {
        if (d.type !== 'hline') continue;
        const y = this.priceToY(d.a.p, m);
        if (y < m.top || y > m.top + m.h) continue;
        c.textAlign = 'left';
        this._tag(this.plotW + 1, y, fmt(d.a.p, this.dec), d.id === this.selId ? '#ffd27d' : THEME.amber, '#1a1205');
      }
    }

    _crossIdx() {
      return Math.max(0, Math.min(this.data.length - 1, Math.round(this.idxAt(this.cross.x))));
    }
    _crosshair() {
      if (!this.cross) return;
      const c = this.ctx, { x, y } = this.cross;
      if (x < 0 || x > this.plotW) return;
      const i = this._crossIdx();
      const cx = Math.round(this.x(i)) + 0.5;
      c.save();
      c.strokeStyle = THEME.cross; c.lineWidth = 1; c.setLineDash([4, 4]);
      c.beginPath();
      c.moveTo(cx, 0); c.lineTo(cx, this.timeTop);
      const pane = this.paneAt(y);
      if (pane) { c.moveTo(0, Math.round(y) + 0.5); c.lineTo(this.plotW, Math.round(y) + 0.5); }
      c.stroke(); c.setLineDash([]);
      c.restore();
      if (pane) {
        const v = this.yToPrice(y, pane);
        c.textAlign = 'left';
        this._tag(this.plotW + 1, y, pane.id === 'main' ? fmt(v, this.dec) : fmt(v, 2), THEME.tag, THEME.text);
      }
      const label = fmtTime(this.data[i].t, this.tfSec);
      c.font = FONT;
      const w = c.measureText(label).width + 12;
      const lx = Math.max(w / 2, Math.min(this.plotW - w / 2, cx));
      this._tag(lx, this.timeTop + this.timeH / 2 + 1, label, THEME.tag, THEME.text, 'center');
    }

    _legend(i) {
      if (!this.cb.onLegend) return;
      if (i < 0 || !this.data.length) { this.cb.onLegend(null); return; }
      const b = this.data[i], prev = this.data[i - 1];
      const chg = prev ? (b.c - prev.c) / prev.c * 100 : 0;
      const vals = [];
      const I = this.I, g = this.ind, f = (a, d) => (a && !isNaN(a[i])) ? fmt(a[i], d === undefined ? this.dec : d) : '–';
      if (g.sma.on) vals.push({ name: `SMA ${g.sma.n}`, color: THEME.amber, text: f(I.sma) });
      if (g.ema.on) vals.push({ name: `EMA ${g.ema.n}`, color: THEME.cyan, text: f(I.ema) });
      if (g.bb.on) vals.push({ name: `BB ${g.bb.n}`, color: THEME.accent, text: I.bb ? `${f(I.bb.up)} / ${f(I.bb.lo)}` : '–' });
      if (g.rsi.on) vals.push({ name: `RSI ${g.rsi.n}`, color: THEME.pink, text: f(I.rsi, 1) });
      if (g.macd.on) vals.push({ name: 'MACD', color: THEME.cyan, text: I.macd ? `${f(I.macd.macd, 3)} · ${f(I.macd.signal, 3)} · ${f(I.macd.hist, 3)}` : '–' });
      this.cb.onLegend({
        o: fmt(b.o, this.dec), h: fmt(b.h, this.dec), l: fmt(b.l, this.dec), c: fmt(b.c, this.dec),
        chg: (chg >= 0 ? '+' : '') + fmt(chg, 2) + ' %', up: chg >= 0, vals
      });
    }

    /* --- Zeichenwerkzeuge --- */
    _geom(d) {
      const xa = this.timeToX(d.a.t), ya = this.priceToY(d.a.p);
      if (d.type === 'hline') return { xa, ya };
      return { xa, ya, xb: this.timeToX(d.b.t), yb: this.priceToY(d.b.p) };
    }
    _drawings() {
      const c = this.ctx, m = this.panes[0];
      this._clip(m);
      const list = this.drawings.slice();
      if (this.pending && this.cross) {
        const pt = this._pointAt(this.cross);
        if (pt) list.push({ id: '_prev', type: this.pending.type, a: this.pending.a, b: pt, preview: true });
      }
      for (const d of list) this._drawOne(d, d.id === this.selId);
      c.restore();
    }
    _drawOne(d, sel) {
      const c = this.ctx, m = this.panes[0], g = this._geom(d);
      c.lineWidth = sel ? 2.2 : 1.6; c.setLineDash(d.preview ? [5, 4] : []);
      const handle = (x, y) => {
        c.setLineDash([]);
        c.fillStyle = THEME.bg; c.strokeStyle = THEME.line; c.lineWidth = 2;
        c.beginPath(); c.arc(x, y, 6, 0, Math.PI * 2); c.fill(); c.stroke();
      };
      if (d.type === 'hline') {
        c.strokeStyle = THEME.amber;
        c.beginPath(); c.moveTo(0, g.ya); c.lineTo(this.plotW, g.ya); c.stroke();
        if (sel) handle(this.plotW * 0.5, g.ya);
      } else if (d.type === 'trend') {
        c.strokeStyle = THEME.accent;
        c.beginPath(); c.moveTo(g.xa, g.ya); c.lineTo(g.xb, g.yb); c.stroke();
        if (sel || d.preview) { handle(g.xa, g.ya); if (!d.preview) handle(g.xb, g.yb); }
      } else if (d.type === 'rect') {
        const x = Math.min(g.xa, g.xb), y = Math.min(g.ya, g.yb), w = Math.abs(g.xb - g.xa), h = Math.abs(g.yb - g.ya);
        c.fillStyle = 'rgba(76,201,240,0.12)'; c.strokeStyle = THEME.cyan;
        c.fillRect(x, y, w, h); c.strokeRect(x, y, w, h);
        if (sel) { handle(g.xa, g.ya); handle(g.xb, g.yb); }
      } else if (d.type === 'fib') {
        const x1 = Math.min(g.xa, g.xb), x2 = this.plotW;
        const lv = FIB.map(L => d.b.p + (d.a.p - d.b.p) * L);
        c.font = '10px ' + FONT.split('px ')[1];
        for (let k = 0; k < FIB.length; k++) {
          const y = this.priceToY(lv[k]);
          if (k < FIB.length - 1) {
            const y2 = this.priceToY(lv[k + 1]);
            c.fillStyle = FIB_COL[k] + '14';
            c.fillRect(x1, Math.min(y, y2), x2 - x1, Math.abs(y2 - y));
          }
          c.strokeStyle = FIB_COL[k]; c.lineWidth = 1;
          c.beginPath(); c.moveTo(x1, y); c.lineTo(x2, y); c.stroke();
          c.fillStyle = FIB_COL[k]; c.textAlign = 'left'; c.textBaseline = 'bottom';
          c.fillText(`${FIB[k]}  (${fmt(lv[k], this.dec)})`, x1 + 4, y - 2);
        }
        c.font = FONT; c.textBaseline = 'middle';
        c.strokeStyle = 'rgba(200,210,230,0.45)'; c.setLineDash([4, 4]);
        c.beginPath(); c.moveTo(g.xa, g.ya); c.lineTo(g.xb, g.yb); c.stroke();
        if (sel || d.preview) { handle(g.xa, g.ya); if (!d.preview) handle(g.xb, g.yb); }
      }
      c.setLineDash([]);
    }

    _pointAt(p) {
      if (!this.data.length) return null;
      const m = this.panes[0];
      const y = Math.max(m.top, Math.min(m.top + m.h, p.y));
      const i = Math.max(-200, Math.min(this.data.length + 200, Math.round(this.idxAt(p.x))));
      let price = this.yToPrice(y);
      if (this.magnet && i >= 0 && i < this.data.length) {
        const b = this.data[i];
        let best = null, bd = 16;
        for (const v of [b.o, b.h, b.l, b.c]) {
          const dd = Math.abs(this.priceToY(v) - y);
          if (dd < bd) { bd = dd; best = v; }
        }
        if (best !== null) price = best;
      }
      return { t: this.idxToTime(i), p: price };
    }
    setTool(t) { this.tool = t; this.pending = null; this.dirty = true; }
    setDrawings(list) { this.drawings = list || []; this.selId = null; this.dirty = true; }
    select(id) {
      this.selId = id; this.dirty = true;
      if (this.cb.onSelect) this.cb.onSelect(id);
    }
    deleteSelected() {
      if (!this.selId) return;
      this.drawings = this.drawings.filter(d => d.id !== this.selId);
      this.select(null); this._changed();
    }
    clearDrawings() { this.drawings = []; this.select(null); this._changed(); }
    _changed() { this.dirty = true; if (this.cb.onDrawings) this.cb.onDrawings(this.drawings); }

    _place(p) {
      const pt = this._pointAt(p);
      if (!pt) return;
      if (this.tool === 'hline') {
        const d = { id: uid(), type: 'hline', a: pt };
        this.drawings.push(d); this._finishTool(d);
      } else if (!this.pending) {
        this.pending = { type: this.tool, a: pt };
        this.cross = { x: p.x, y: p.y };
      } else {
        const d = { id: uid(), type: this.tool, a: this.pending.a, b: pt };
        this.drawings.push(d); this._finishTool(d);
      }
      this.dirty = true;
    }
    _finishTool(d) {
      this.tool = null; this.pending = null; this.cross = null;
      this._changed();
      this.select(d.id);
      if (this.cb.onToolDone) this.cb.onToolDone();
    }
    _hitDrawing(p) {
      const m = this.panes[0];
      if (!m || p.y > m.top + m.h || p.x > this.plotW) return null;
      for (let k = this.drawings.length - 1; k >= 0; k--) {
        const d = this.drawings[k], g = this._geom(d);
        if (d.type === 'hline') { if (Math.abs(p.y - g.ya) < 14) return d; }
        else if (d.type === 'trend') { if (distSeg(p, g.xa, g.ya, g.xb, g.yb) < 14) return d; }
        else if (d.type === 'rect') {
          const x1 = Math.min(g.xa, g.xb), x2 = Math.max(g.xa, g.xb), y1 = Math.min(g.ya, g.yb), y2 = Math.max(g.ya, g.yb);
          if (p.x >= x1 - 8 && p.x <= x2 + 8 && p.y >= y1 - 8 && p.y <= y2 + 8) return d;
        } else if (d.type === 'fib') {
          const x1 = Math.min(g.xa, g.xb);
          if (p.x >= x1 - 8) for (const L of FIB) if (Math.abs(p.y - this.priceToY(d.b.p + (d.a.p - d.b.p) * L)) < 12) return d;
        }
      }
      return null;
    }
    _hitHandle(p) {
      const d = this.drawings.find(x => x.id === this.selId);
      if (!d) return null;
      const g = this._geom(d);
      if (d.type === 'hline') return Math.abs(p.y - g.ya) < 18 ? { d, which: 'a' } : null;
      if (Math.hypot(p.x - g.xa, p.y - g.ya) < 22) return { d, which: 'a' };
      if (Math.hypot(p.x - g.xb, p.y - g.yb) < 22) return { d, which: 'b' };
      return null;
    }

    /* --- Eingabe --- */
    _pos(e) {
      const r = this.cv.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    _bind() {
      const cv = this.cv;
      cv.style.touchAction = 'none';
      cv.addEventListener('pointerdown', e => this._down(e));
      cv.addEventListener('pointermove', e => this._move(e));
      cv.addEventListener('pointerup', e => this._up(e));
      cv.addEventListener('pointercancel', e => this._up(e, true));
      cv.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse' && !this.ptrs.size && !this.pending) { this.cross = null; this.dirty = true; } });
      cv.addEventListener('wheel', e => {
        e.preventDefault();
        const p = this._pos(e);
        if (e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
          this.rightOff -= (e.deltaX || e.deltaY) / this.bw; this._viewChanged(); this.dirty = true;
        } else this.zoomTo(this.bw * Math.exp(-e.deltaY * 0.0015), p.x);
      }, { passive: false });
      cv.addEventListener('dblclick', () => this.resetView());
      cv.addEventListener('contextmenu', e => e.preventDefault());
    }
    _down(e) {
      try { this.cv.setPointerCapture(e.pointerId); } catch (_) { }
      const p = this._pos(e);
      this.ptrs.set(e.pointerId, { x: p.x, y: p.y });
      if (this.ptrs.size === 2) {
        const [a, b] = [...this.ptrs.values()];
        this.pinch = { d: Math.abs(a.x - b.x) || 1, bw: this.bw };
        this.mode = 'pinch'; clearTimeout(this.lp); return;
      }
      if (this.ptrs.size > 2) return;
      this.down = { x: p.x, y: p.y };
      const h = (!this.tool) ? this._hitHandle(p) : null;
      if (h) { this.mode = 'handle'; this.dragH = h; return; }
      this.mode = 'tap';
      this.panStart = { x: p.x, rightOff: this.rightOff };
      if (e.pointerType !== 'mouse') {
        clearTimeout(this.lp);
        this.lp = setTimeout(() => {
          if (this.mode === 'tap') {
            this.mode = 'cross'; this.cross = { x: p.x, y: p.y }; this.dirty = true;
            if (navigator.vibrate) try { navigator.vibrate(12); } catch (_) { }
          }
        }, 380);
      }
    }
    _move(e) {
      const p = this._pos(e);
      const o = this.ptrs.get(e.pointerId);
      if (!o) {
        if (e.pointerType === 'mouse') { this.cross = { x: p.x, y: p.y }; this.dirty = true; }
        return;
      }
      o.x = p.x; o.y = p.y;
      if (this.mode === 'pinch' && this.ptrs.size >= 2) {
        const [a, b] = [...this.ptrs.values()];
        this.zoomTo(this.pinch.bw * (Math.abs(a.x - b.x) || 1) / this.pinch.d, (a.x + b.x) / 2);
        return;
      }
      if (this.mode === 'handle') {
        const pt = this._pointAt(p);
        if (pt) {
          const { d, which } = this.dragH;
          d[which] = d.type === 'hline' ? { t: d.a.t, p: pt.p } : pt;
          this.dirty = true;
        }
        return;
      }
      if (this.mode === 'cross') { this.cross = { x: p.x, y: p.y }; this.dirty = true; return; }
      if (this.mode === 'tap' && Math.hypot(p.x - this.down.x, p.y - this.down.y) > 8) {
        this.mode = 'pan'; clearTimeout(this.lp);
      }
      if (this.mode === 'pan') {
        this.rightOff = this.panStart.rightOff - (p.x - this.panStart.x) / this.bw;
        this._viewChanged(); this.dirty = true;
      }
      if (e.pointerType === 'mouse' && this.pending) { this.cross = { x: p.x, y: p.y }; this.dirty = true; }
    }
    _up(e, cancel) {
      clearTimeout(this.lp);
      const p = this._pos(e);
      const was = this.mode;
      this.ptrs.delete(e.pointerId);
      if (was === 'pinch') { this.mode = this.ptrs.size ? 'none' : null; return; }
      if (was === 'handle') { this._changed(); this.mode = null; return; }
      if (was === 'tap' && !cancel) {
        if (this.tool) this._place(p);
        else {
          const hit = this._hitDrawing(p);
          if (hit) this.select(hit.id);
          else if (this.selId) this.select(null);
          else if (this.cross && e.pointerType !== 'mouse') { this.cross = null; this.dirty = true; }
        }
      }
      if (!this.ptrs.size) this.mode = null;
    }
  }

  root.TradseeChart = TradseeChart;
  root.TradseeCalc = calc;
  root.TradseeFmt = { fmt, autoDec, fmtTime };
})(typeof window !== 'undefined' ? window : globalThis);
