/* Tradsee – App-Logik (UI, Datenquelle, Watchlist, Einstellungen) */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const { fmt, autoDec } = window.TradseeFmt;

  /* ---------- Speicher ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem('tradsee.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('tradsee.' + k, JSON.stringify(v)); } catch (e) { } }
  };

  /* ---------- Konfiguration ---------- */
  const TFS = [
    { id: '1m', label: '1m', sec: 60 }, { id: '5m', label: '5m', sec: 300 }, { id: '15m', label: '15m', sec: 900 },
    { id: '1h', label: '1h', sec: 3600 }, { id: '4h', label: '4h', sec: 14400 },
    { id: '1d', label: '1T', sec: 86400 }, { id: '1w', label: '1W', sec: 604800 }
  ];
  const TYPES = [
    { id: 'candles', name: 'Kerzen', sub: 'Klassische Candlesticks' },
    { id: 'bars', name: 'Balken', sub: 'OHLC-Bars' },
    { id: 'line', name: 'Linie', sub: 'Schlusskurse' },
    { id: 'area', name: 'Fläche', sub: 'Linie mit Verlauf' },
    { id: 'ha', name: 'Heikin Ashi', sub: 'Geglättete Kerzen' }
  ];
  const BASES = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'ADA', 'DOGE', 'AVAX', 'DOT', 'LINK', 'LTC', 'TRX', 'ATOM', 'UNI', 'NEAR',
    'APT', 'ARB', 'OP', 'INJ', 'SUI', 'TON', 'SHIB', 'PEPE', 'FIL', 'AAVE', 'ETC', 'XLM', 'BCH', 'HBAR', 'POL'];
  const SYMBOLS = BASES.map(b => b + 'USDT').concat(['BTCEUR', 'ETHEUR', 'SOLEUR', 'XRPEUR']);
  const DEFAULT_FAVS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'BNBUSDT', 'DOGEUSDT'];
  const DEFAULT_IND = {
    sma: { on: true, n: 20 }, ema: { on: false, n: 50 }, bb: { on: false, n: 20, k: 2 },
    vol: { on: true }, rsi: { on: false, n: 14 }, macd: { on: false }
  };

  const splitSym = s => {
    for (const q of ['USDT', 'EUR', 'USDC', 'BUSD', 'BTC', 'ETH', 'BNB']) if (s.endsWith(q) && s.length > q.length) return [s.slice(0, -q.length), q];
    return [s, ''];
  };

  /* ---------- Datenquelle (Binance, öffentlich, ohne API-Key) ---------- */
  const Provider = {
    rest: ['https://api.binance.com', 'https://data-api.binance.vision'],
    ws: ['wss://stream.binance.com:9443', 'wss://data-stream.binance.vision'],
    async getJSON(path) {
      let err;
      for (const base of this.rest) {
        try {
          const ctl = new AbortController();
          const to = setTimeout(() => ctl.abort(), 8000);
          const r = await fetch(base + path, { signal: ctl.signal });
          clearTimeout(to);
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return await r.json();
        } catch (e) { err = e; }
      }
      throw err;
    },
    async klines(symbol, tf, endMs) {
      let p = `/api/v3/klines?symbol=${symbol}&interval=${tf}&limit=1000`;
      if (endMs) p += `&endTime=${endMs}`;
      const a = await this.getJSON(p);
      return a.map(k => ({ t: Math.floor(k[0] / 1000), o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
    },
    async tickers(symbols) {
      let a;
      try {
        a = await this.getJSON('/api/v3/ticker/24hr?symbols=' + encodeURIComponent(JSON.stringify(symbols)));
      } catch (e) {
        // Ein ungültiges Symbol lässt den Sammelabruf scheitern: dann alle Ticker laden und filtern
        if (!/HTTP 4/.test(String(e.message))) throw e;
        const set = new Set(symbols);
        a = (await this.getJSON('/api/v3/ticker/24hr')).filter(x => set.has(x.symbol));
      }
      return a.map(x => ({ symbol: x.symbol, price: +x.lastPrice, pct: +x.priceChangePercent }));
    },
    stream(symbol, tf, onBar, onState) {
      let ws, closed = false, idx = 0, retry = 0, timer;
      const schedule = () => { if (closed) return; idx++; retry++; timer = setTimeout(open, Math.min(1000 * retry, 8000)); };
      const open = () => {
        if (closed) return;
        try { ws = new WebSocket(`${this.ws[idx % this.ws.length]}/ws/${symbol.toLowerCase()}@kline_${tf}`); } catch (e) { schedule(); return; }
        ws.onopen = () => { retry = 0; onState && onState(true); };
        ws.onmessage = ev => {
          try { const k = JSON.parse(ev.data).k; if (k) onBar({ t: Math.floor(k.t / 1000), o: +k.o, h: +k.h, l: +k.l, c: +k.c, v: +k.v }); } catch (e) { }
        };
        ws.onclose = () => { onState && onState(false); schedule(); };
        ws.onerror = () => { try { ws.close(); } catch (e) { } };
      };
      open();
      return { close() { closed = true; clearTimeout(timer); try { ws && ws.close(); } catch (e) { } } };
    }
  };

  /* Demo-Daten (nur wenn keine Verbindung besteht, deutlich gekennzeichnet) */
  function demoBars(tfSec, n) {
    n = n || 800;
    let seed = 20261025;
    const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
    let t = Math.floor(Date.now() / 1000 / tfSec) * tfSec - (n - 1) * tfSec;
    let p = 100, drift = 0;
    const out = [];
    for (let i = 0; i < n; i++) {
      drift = drift * 0.92 + (rnd() - 0.5) * 0.004;
      const o = p, c = o * (1 + drift + (rnd() - 0.5) * 0.012);
      const h = Math.max(o, c) * (1 + rnd() * 0.004), l = Math.min(o, c) * (1 - rnd() * 0.004);
      out.push({ t, o, h, l, c, v: 100 + rnd() * 900 });
      p = c; t += tfSec;
    }
    return out;
  }

  /* ---------- Zustand ---------- */
  const state = {
    symbol: store.get('symbol', 'BTCUSDT'),
    tf: store.get('tf', '1h'),
    type: store.get('type', 'candles'),
    favs: store.get('favs', DEFAULT_FAVS),
    magnet: store.get('magnet', true)
  };
  const savedInd = store.get('ind', {});
  const ind = {};
  for (const k in DEFAULT_IND) ind[k] = Object.assign({}, DEFAULT_IND[k], savedInd[k] || {});
  if (!TFS.some(t => t.id === state.tf)) state.tf = '1h';
  const tfSec = () => TFS.find(t => t.id === state.tf).sec;

  /* ---------- Chart ---------- */
  const cv = $('#cv');
  const legendEl = $('#legend');
  const chart = new window.TradseeChart(cv, {
    onLegend(l) {
      if (!l) { legendEl.innerHTML = ''; return; }
      const cls = l.up ? 'up' : 'down';
      legendEl.innerHTML =
        `<div class="ohlc"><span>O<b class="${cls}">${l.o}</b></span><span>H<b class="${cls}">${l.h}</b></span><span>L<b class="${cls}">${l.l}</b></span><span>C<b class="${cls}">${l.c}</b></span><span class="${cls}">${l.chg}</span></div>` +
        (l.vals.length ? `<div class="ind">${l.vals.map(v => `<span style="color:${v.color}">${v.name} ${v.text}</span>`).join('')}</div>` : '');
    },
    onView(off) { $('#to-now').classList.toggle('hidden', off >= -1); },
    onNeedMore() { loadMore(); },
    onDrawings(list) { store.set('draw.' + state.symbol, list); },
    onSelect(id) { const t = $('#trash'); t.disabled = !id; t.classList.toggle('armed', !!id); },
    onToolDone() { setToolUI(null); }
  });
  chart.setType(state.type);
  chart.setIndicators(ind);
  chart.magnet = state.magnet;
  new ResizeObserver(() => chart.resize()).observe($('#chart-wrap'));
  window.addEventListener('resize', () => chart.resize());

  /* ---------- Laden ---------- */
  let lastGood = state.symbol, reqId = 0, streamH = null, demo = false, moreBusy = false, noMore = false, retryTimer = null, tickTimer = null;
  const TOASTS = {
    trend: 'Startpunkt antippen, dann Endpunkt',
    hline: 'Preislevel antippen',
    fib: 'Start- und Endpunkt antippen',
    rect: 'Zwei gegenüberliegende Ecken antippen'
  };

  function banner(text) {
    const b = $('#banner');
    b.textContent = text || '';
    b.classList.toggle('hidden', !text);
  }
  function busy(on) { $('#busy').classList.toggle('hidden', !on); }
  let toastT;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.remove('hidden');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hidden'), 2600);
  }

  function updateHeader(pct) {
    const d = chart.data;
    if (!d.length) return;
    const last = d[d.length - 1];
    const [b, q] = splitSym(state.symbol);
    $('#sym-name').innerHTML = `${b}<i>/${q}</i>`;
    $('#price').textContent = fmt(last.c, autoDec(last.c)) + (demo ? ' (Demo)' : '');
    const el = $('#change');
    if (typeof pct === 'number') updateHeader.pct = pct;
    let p = updateHeader.pct;
    if (typeof p !== 'number') {
      const first = d[Math.max(0, d.length - 25)];
      p = (last.c - first.c) / first.c * 100;
    }
    el.textContent = (p >= 0 ? '+' : '') + fmt(p, 2) + ' %';
    el.className = 'chg ' + (p >= 0 ? 'up' : 'down');
  }

  async function load() {
    const id = ++reqId;
    clearTimeout(retryTimer);
    if (streamH) { streamH.close(); streamH = null; }
    noMore = false; moreBusy = false; updateHeader.pct = undefined;
    busy(true);
    let bars = null, bad = false;
    try { bars = await Provider.klines(state.symbol, state.tf); } catch (e) { bars = null; bad = /HTTP 4(00|04)/.test(String(e.message)); }
    if (id !== reqId) return;
    if (bad && state.symbol !== lastGood) {
      toast('Symbol „' + state.symbol + '“ nicht gefunden');
      state.symbol = lastGood; store.set('symbol', lastGood);
      return load();
    }
    if (!bad) lastGood = state.symbol;
    demo = !bars || !bars.length;
    if (demo) bars = demoBars(tfSec());
    chart.setData(bars, tfSec(), true);
    chart.setDrawings(store.get('draw.' + state.symbol, []));
    updateHeader();
    banner(demo ? 'Keine Verbindung – Demo-Daten (antippen für neuen Versuch)' : '');
    busy(false);
    if (demo) { retryTimer = setTimeout(load, 20000); return; }
    streamH = Provider.stream(state.symbol, state.tf, bar => { chart.updateBar(bar); updateHeader(); });
    fetchTicker();
  }
  async function fetchTicker() {
    const sym = state.symbol;
    try {
      const [t] = await Provider.tickers([sym]);
      if (t && sym === state.symbol) updateHeader(t.pct);
    } catch (e) { }
    clearTimeout(tickTimer);
    tickTimer = setTimeout(() => { if (!demo) fetchTicker(); }, 30000);
  }
  async function loadMore() {
    if (demo || moreBusy || noMore || chart.data.length >= 6000) return;
    moreBusy = true;
    const id = reqId, first = chart.data[0];
    try {
      const older = await Provider.klines(state.symbol, state.tf, first.t * 1000 - 1);
      if (id === reqId) { if (older.length) chart.prepend(older); else noMore = true; }
    } catch (e) { }
    moreBusy = false;
  }
  $('#banner').addEventListener('click', () => load());

  /* ---------- Zeitrahmen ---------- */
  const tfBox = $('#tfs');
  tfBox.innerHTML = TFS.map(t => `<button data-tf="${t.id}">${t.label}</button>`).join('');
  function markTf() { tfBox.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.tf === state.tf)); }
  tfBox.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b || b.dataset.tf === state.tf) return;
    state.tf = b.dataset.tf; store.set('tf', state.tf); markTf(); load();
  });
  markTf();

  /* ---------- Werkzeugleiste ---------- */
  function setToolUI(t) {
    document.querySelectorAll('#tools .tool[data-tool]').forEach(b => b.classList.toggle('on', b.dataset.tool === (t || '')));
  }
  $('#tools').addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.tool !== undefined) {
      const t = b.dataset.tool || null;
      chart.setTool(t); chart.select(null); setToolUI(t);
      if (t) toast(TOASTS[t]);
    }
  });
  $('#magnet').classList.toggle('on', state.magnet);
  $('#magnet').addEventListener('click', () => {
    state.magnet = !state.magnet; chart.magnet = state.magnet; store.set('magnet', state.magnet);
    $('#magnet').classList.toggle('on', state.magnet);
    toast(state.magnet ? 'Magnet an: rastet an Kerzenwerten ein' : 'Magnet aus');
  });
  $('#trash').addEventListener('click', () => chart.deleteSelected());
  $('#trash').addEventListener('contextmenu', e => { e.preventDefault(); });
  let trashHold;
  $('#trash').addEventListener('pointerdown', () => { trashHold = setTimeout(() => { if (confirm('Alle Zeichnungen für diesen Markt löschen?')) chart.clearDrawings(); }, 900); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => $('#trash').addEventListener(ev, () => clearTimeout(trashHold)));
  $('#to-now').addEventListener('click', () => { chart.rightOff = 6; chart._viewChanged(); chart.dirty = true; });

  /* ---------- Sheets ---------- */
  let sheetOpen = false, sheetCleanup = null;
  function openSheet(title, node, cleanup) {
    $('#sheet-title').textContent = title;
    const body = $('#sheet-body');
    body.innerHTML = '';
    body.appendChild(node);
    $('#sheet').classList.remove('hidden');
    $('#backdrop').classList.remove('hidden');
    sheetOpen = true; sheetCleanup = cleanup || null;
  }
  function closeSheet() {
    $('#sheet').classList.add('hidden');
    $('#backdrop').classList.add('hidden');
    sheetOpen = false;
    if (sheetCleanup) { sheetCleanup(); sheetCleanup = null; }
  }
  $('#backdrop').addEventListener('click', closeSheet);
  const el = html => { const d = document.createElement('div'); d.innerHTML = html.trim(); return d; };

  /* Märkte / Watchlist */
  const tickCache = {};
  $('#sym-btn').addEventListener('click', openSymbols);
  function openSymbols() {
    const root = el(`<div><input class="search" id="q" placeholder="Markt suchen, z. B. SOL oder PEPEUSDT" autocomplete="off" autocapitalize="characters" spellcheck="false"><div id="list"></div></div>`);
    const input = $('#q', root), list = $('#list', root);
    let timer;
    const row = s => {
      const [b, q] = splitSym(s), t = tickCache[s], fav = state.favs.includes(s);
      const cls = t ? (t.pct >= 0 ? 'up' : 'down') : '';
      return `<div class="row" data-s="${s}"><div class="rs">${b}<i>/${q}</i></div>` +
        `<div class="rp">${t ? fmt(t.price, autoDec(t.price)) : '–'}</div>` +
        `<div class="rc ${cls}">${t ? (t.pct >= 0 ? '+' : '') + fmt(t.pct, 2) + ' %' : '–'}</div>` +
        `<button class="star ${fav ? 'on' : ''}" data-star="${s}" aria-label="Favorit">${fav ? '★' : '☆'}</button></div>`;
    };
    const render = () => {
      const q = input.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
      let html = '';
      if (!q) {
        html += `<div class="sec">Watchlist</div>` + (state.favs.length ? state.favs.map(row).join('') : '<div class="row">Noch leer – tippe ☆ bei einem Markt</div>');
        html += `<div class="sec">Alle Märkte</div>` + SYMBOLS.filter(s => !state.favs.includes(s)).map(row).join('');
      } else {
        const hits = SYMBOLS.filter(s => s.includes(q));
        html += hits.map(row).join('');
        if (!SYMBOLS.includes(q) && q.length >= 5) html += `<div class="sec">Eigenes Symbol</div>` + row(q);
        if (!html) html = '<div class="row">Nichts gefunden</div>';
      }
      list.innerHTML = html;
    };
    const refresh = async () => {
      const shown = new Set(SYMBOLS);
      try {
        const a = await Provider.tickers([...shown]);
        a.forEach(t => { tickCache[t.symbol] = t; });
        if (sheetOpen) { const y = $('#sheet-body').scrollTop; render(); $('#sheet-body').scrollTop = y; }
      } catch (e) { }
      timer = setTimeout(refresh, 8000);
    };
    list.addEventListener('click', e => {
      const star = e.target.closest('[data-star]');
      if (star) {
        const s = star.dataset.star;
        state.favs = state.favs.includes(s) ? state.favs.filter(x => x !== s) : state.favs.concat(s);
        store.set('favs', state.favs);
        const y = $('#sheet-body').scrollTop; render(); $('#sheet-body').scrollTop = y;
        return;
      }
      const r = e.target.closest('.row[data-s]');
      if (!r) return;
      closeSheet();
      if (r.dataset.s !== state.symbol) { state.symbol = r.dataset.s; store.set('symbol', state.symbol); load(); }
    });
    input.addEventListener('input', render);
    render();
    openSheet('Märkte', root, () => clearTimeout(timer));
    refresh();
  }

  /* Indikatoren */
  $('#ind-btn').addEventListener('click', () => {
    const defs = [
      { k: 'sma', name: 'SMA', sub: 'Gleitender Durchschnitt', color: '#ffb547', num: 'n' },
      { k: 'ema', name: 'EMA', sub: 'Exponentieller Durchschnitt', color: '#4cc9f0', num: 'n' },
      { k: 'bb', name: 'Bollinger-Bänder', sub: 'Volatilitätskanal (2 σ)', color: '#8b7cff', num: 'n' },
      { k: 'vol', name: 'Volumen', sub: 'Handelsvolumen am Chartboden', color: '#7b8598' },
      { k: 'rsi', name: 'RSI', sub: 'Relative Stärke (eigenes Fenster)', color: '#f472b6', num: 'n' },
      { k: 'macd', name: 'MACD', sub: '12 / 26 / 9 (eigenes Fenster)', color: '#4cc9f0' }
    ];
    const root = el('<div></div>');
    root.innerHTML = defs.map(d => `<div class="opt" data-k="${d.k}"><span class="dot" style="background:${d.color}"></span>` +
      `<div class="nm">${d.name}<small>${d.sub}</small></div>` +
      (d.num ? `<input type="number" inputmode="numeric" min="2" max="200" value="${ind[d.k][d.num]}" data-num="${d.k}">` : '') +
      `<div class="sw ${ind[d.k].on ? 'on' : ''}" data-sw="${d.k}"></div></div>`).join('');
    const apply = () => { store.set('ind', ind); chart.setIndicators(Object.assign({}, ind)); };
    root.addEventListener('click', e => {
      const sw = e.target.closest('[data-sw]');
      if (!sw) return;
      const k = sw.dataset.sw;
      ind[k].on = !ind[k].on; sw.classList.toggle('on', ind[k].on); apply();
    });
    root.addEventListener('change', e => {
      const n = e.target.closest('[data-num]');
      if (!n) return;
      const v = Math.max(2, Math.min(200, parseInt(n.value, 10) || ind[n.dataset.num].n));
      ind[n.dataset.num].n = v; n.value = v; apply();
    });
    openSheet('Indikatoren', root);
  });

  /* Chart-Typ */
  $('#type-btn').addEventListener('click', () => {
    const root = el('<div></div>');
    root.innerHTML = TYPES.map(t => `<div class="opt ${t.id === state.type ? 'sel' : ''}" data-t="${t.id}"><span class="radio"></span><div class="nm">${t.name}<small>${t.sub}</small></div></div>`).join('');
    root.addEventListener('click', e => {
      const o = e.target.closest('[data-t]');
      if (!o) return;
      state.type = o.dataset.t; store.set('type', state.type); chart.setType(state.type); closeSheet();
    });
    openSheet('Chart-Typ', root);
  });

  /* Info */
  $('#info-btn').addEventListener('click', () => {
    openSheet('Über Tradsee', el(`<div class="about">
      <p><b>Tradsee</b> ist eine unabhängige Chart-App mit eigener Chart-Engine. Sie steht in keiner Verbindung zu TradingView oder anderen Anbietern.</p>
      <p><b>Bedienung:</b> Wischen verschiebt, Zwei-Finger-Geste zoomt, langes Drücken zeigt das Fadenkreuz. Doppeltippen (oder Doppelklick) setzt die Ansicht zurück. Der Papierkorb löscht die markierte Zeichnung, langes Drücken löscht alle.</p>
      <p><b>Daten:</b> Öffentliche Kursdaten von Binance (Krypto). Zeichnungen und Einstellungen bleiben lokal auf deinem Gerät.</p>
      <p>Keine Anlageberatung. Kurse können verzögert oder fehlerhaft sein.</p>
    </div>`));
  });

  /* Android-Zurück-Taste */
  window.tradseeBack = function () {
    if (sheetOpen) { closeSheet(); return true; }
    if (chart.tool || chart.pending) { chart.setTool(null); setToolUI(null); return true; }
    if (chart.selId) { chart.select(null); return true; }
    return false;
  };

  load();
})();
